//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
//closure in swift

//sorted closure
var months = [4,3,1,6,5,2]
print(months.sorted())
func reverse(_ s1: Int, _ s2: Int ) -> Bool {
    return s1 > s2
}
var reversedMonths = months.sorted(by: reverse)
print("reversedMonths",reversedMonths)

func increasing(_ s1: Int, _ s2:Int) -> Bool {
    return s1 < s2
}

var increasingMonths = months.sorted(by: increasing)
print("increasing months : ",increasingMonths)

var reverseClosure = months.sorted(by: {
    (s1: Int,s2: Int) -> Bool in
return s1 > s2
})

print("reverseClosure",reverseClosure)

//inferring parameter types from context
var inferTypes = months.sorted(by: {
//(s1, s2) in return s1 < s2
(s1, s2) in s1 < s2 //implicit return)
})
print("inferTypes : ",inferTypes)

//shorthand argument names
print("shorthand argument : ", months.sorted(by: {$0 < $1}))

//operator methods
    print("operator methods : ",months.sorted(by:<))

var three = [1,3,4,5,6,8,12,15]
print("three : ", three)

var modThree = three.filter({$0 % 3 == 0})
print("modThree : ", modThree)

//nested functions closure
func makeIncrementer(forIncrement amount: Int) -> () -> Int {
    var runningTotal = 0
    
    func incrementer() -> Int {
        runningTotal += amount
        return runningTotal
    }
    return incrementer
}
let incrementByTen = makeIncrementer(forIncrement: 10)

print("first call : ",incrementByTen()) //10
print("second call : ",incrementByTen()) //20
print("third call : ",incrementByTen()) //30

let incrementBySeven = makeIncrementer(forIncrement: 7)
print("increment by seven 1 : ",incrementBySeven()) //7
print("increment by seven 2 : ",incrementBySeven()) //14

print("fourth call : ",incrementBySeven()) //40

//Closure are reference type
let incrementBySevenagain = incrementBySeven
print("increment by seven 3 : ",incrementBySevenagain())

//autoclosures
var errorList = [404,414
    ,402,431,455,440]
print("Total Errors : ",errorList.count)

let debugger = { errorList.remove(at: 0) }
print("Total Errors : ",errorList.count)

print("Now solving \(debugger())!")
print("Total Errors : ",errorList.count)

func solve(error debugger: @autoclosure () -> Int) {
    print("Now Solving \(debugger())!")
}
solve(error: errorList.remove(at: 0))

print("Error List : ", errorList)
// declaring a structure

struct project {
    var title = ""
    var hours = 0
    
    func dispaly(){
        print("project Title : ",title)
        print("Total work hours required : ",hours)
    }
}

//declaring instance of structure
var LMSProject = project(title: "moodle",hours :200)
print(LMSProject)

LMSProject.dispaly()

LMSProject.hours = 300
LMSProject.dispaly()
    
    
//class declaration
class Manager{
    var name : String = ""
    var productOwner : Bool = true
    var currentProject = project()
}

let mgrCanada = Manager()
mgrCanada.name  = "Jk"
mgrCanada.productOwner = true
//mgrCanada.currentProjects=project(title: "Sales Reporting",hours:20)
print("mgrCanada Name : ", mgrCanada.name)
print("mgrCanada product Owner : ", mgrCanada.productOwner)
print("mgrCanada current project Title : ", mgrCanada.currentProject.title)

struct address{
    var street = "265 Yorkland Blvd"
    var city = "North York"
    var postalCode = "M1H1Y1"
}

var lambton = address()
print("Lambton: ",lambton)

var cester = lambton
print("Cester:",cester)

cester.street = "271 yorkland blvd"
cester.postalCode = "M1H3Y3"
print("cester : ",cester)
print("lambton : ",lambton)

class Institute{
var street = "265 Yorkland Blvd"
    var city = "North York"
    var postalCode = "M1H1Y1"
}

var myLambton = Institute()
print("myLambton street: ",myLambton.street)
print("myLambton city: ", myLambton.city)
print("myLambton postalCode: ",myLambton.postalCode)

print("myLambton street: ",myLambton.street)
print("myLambton postalCode: ",myLambton.postalCode)


